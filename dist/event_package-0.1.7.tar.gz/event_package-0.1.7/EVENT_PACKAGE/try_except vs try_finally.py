# try:
#     x = 5 / 0
# except ZeroDivisionError:
#     print("You can't divide by zero!")
    
    
    
    
try:
    x = 5 / 0
finally:
    print("This will always run, no matter what.")